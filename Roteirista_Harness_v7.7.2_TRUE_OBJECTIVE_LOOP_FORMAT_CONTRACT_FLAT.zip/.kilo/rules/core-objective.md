# Core Objective v7.7

A = forma/voz/storytelling. B = conteúdo + ordem TEMÁTICA + tamanho.

O Writer nunca recebe B bruto. B é descompilado antes da escrita.

Release exige:
- 12 gates PASS;
- auditoria determinística PASS;
- forma mais próxima de A que de B;
- release challenge independente do GLM-5.2.

Preservar ordem temática não significa preservar a progressão frase-a-frase de B.
