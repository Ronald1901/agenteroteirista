# Efficiency v7.7

Não explore o workspace se o CLI já forneceu caminhos.
Não crie agentes extras.
Não gere candidatos paralelos.
Não repita etapas já checkpointadas.
Repare somente o objective delta.
Quando houver RELEASED, pare imediatamente.
