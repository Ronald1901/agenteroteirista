# /diagnosticar-roteirista

Execute, nesta ordem:

1. `python rh7_cli.py bootstrap`
2. `python rh7_cli.py doctor`
3. `python rh7_cli.py selftest`
4. `python rh7_cli.py golden-failure-check`
5. `python rh7_cli.py discover-inputs`

O diagnóstico só é considerado saudável se `doctor`, `selftest` e `golden-failure-check` retornarem `ok:true`.
