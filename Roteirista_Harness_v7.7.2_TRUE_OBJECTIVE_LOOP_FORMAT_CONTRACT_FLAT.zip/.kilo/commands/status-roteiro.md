# /status-roteiro

Execute:

`python rh7_cli.py status-latest`

Mostre de forma compacta: barra, fase, modelo ativo, drafts usados, gates falhos/regressões e caminho final quando existir.
