# /continuar-roteiro

Recupere a última run incompleta do disco:

`python rh7_cli.py resume-latest`

Use o `next` retornado e continue obedecendo ao CLI. Não tente lembrar RUN_ID pela conversa e não reinicie do zero.


Se a chamada seguinte retornar quota esgotada, registre com `python rh7_cli.py model-failure RUN_ID --reason quota_exhausted`; o CLI troca o subagente/modelo sem reiniciar a run.
