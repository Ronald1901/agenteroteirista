# /pular-modelo-roteiro

Use somente se uma sessão anterior morreu exatamente em um erro de quota antes de conseguir registrar o failover.

1. Execute `python rh7_cli.py model-failure-latest --reason quota_exhausted`.
2. Use o `next.target`, `next.task_file` e `next.model` retornados.
3. Continue normalmente.

Não use para falha de qualidade do texto.
