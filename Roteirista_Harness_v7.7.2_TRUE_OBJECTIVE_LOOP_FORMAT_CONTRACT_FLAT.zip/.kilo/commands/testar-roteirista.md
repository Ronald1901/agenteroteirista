# /testar-roteirista

Execute:

`python -m unittest discover -s tests -v`

Depois execute:

`python rh7_cli.py golden-failure-check`
