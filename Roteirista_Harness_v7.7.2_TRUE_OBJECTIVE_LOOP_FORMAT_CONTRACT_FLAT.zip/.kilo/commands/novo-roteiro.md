# /novo-roteiro

Inicie uma nova execução v7.7.2 sem explorar manualmente o workspace.

1. `python rh7_cli.py bootstrap`
2. `python rh7_cli.py discover-inputs`
3. Se `ready:false`, informe que faltam A e/ou B e pare.
4. Se `ready:true` e houver `F`, execute:
   `python rh7_cli.py start --a-file "PATH_A" --b-file "PATH_B" --format-file "PATH_F"`
   Se não houver F, execute sem `--format-file`; o formato canônico estilo Arquivo F é aplicado mesmo assim.
5. Pegue o `run_id` retornado e execute `python rh7_cli.py next RUN_ID`.
6. Mostre a barra `progress` apenas quando a fase mudar.
7. Para cada `CALL_SUBAGENT`, chame somente o `target` indicado com `Execute integralmente o task_file: PATH`.
8. Repita `python rh7_cli.py next RUN_ID` até `RELEASED`, `QUALITY_BLOCKED` ou `MODEL_POOL_EXHAUSTED`.
9. Em `RELEASED`, mostre o `final_path`, que fica em `roteiro final/` na raiz.


Se uma chamada de subagente falhar por quota/modelo, NÃO pare: execute `python rh7_cli.py model-failure RUN_ID --reason quota_exhausted`, use o novo `next.target` e continue.
