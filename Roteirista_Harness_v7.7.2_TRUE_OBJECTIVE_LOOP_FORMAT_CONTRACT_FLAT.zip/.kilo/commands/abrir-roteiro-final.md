# /abrir-roteiro-final

Execute:

`python rh7_cli.py latest-final`

Mostre o `final_path`. O arquivo estará dentro de `roteiro final/` na raiz do projeto.
