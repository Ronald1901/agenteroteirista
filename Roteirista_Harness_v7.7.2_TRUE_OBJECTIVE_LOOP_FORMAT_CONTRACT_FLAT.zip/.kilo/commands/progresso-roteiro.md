# /progresso-roteiro

Execute `python rh7_cli.py status-latest` e mostre somente `progress`, modelo ativo, draft_count e gates falhos.
