import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class StructureTests(unittest.TestCase):
    def test_logical_agents_and_fallback_routes_present(self):
        got = {p.name for p in (ROOT / ".kilo" / "agents").glob("*.md")}
        logical = {
            "roteirista-harness-v77.md", "rh77-dna.md", "rh77-b-decompiler.md", "rh77-rewriter.md", "rh77-critic.md", "rh77-second-opinion.md"
        }
        self.assertTrue(logical.issubset(got))
        expected_fallbacks = {
            "rh77-dna-fb-0517.md", "rh77-dna-fb-preview.md", "rh77-dna-fb-36max.md",
            "rh77-b-decompiler-fb-preview.md", "rh77-b-decompiler-fb-0520.md", "rh77-b-decompiler-fb-36max.md",
            "rh77-rewriter-fb-0520.md", "rh77-rewriter-fb-0517.md", "rh77-rewriter-fb-preview.md", "rh77-rewriter-fb-36max.md",
            "rh77-critic-fb-glm52.md", "rh77-critic-fb-qwen-preview.md", "rh77-critic-fb-qwen-0517.md",
            "rh77-second-opinion-fb-qwen-preview.md", "rh77-second-opinion-fb-qwen-0517.md", "rh77-second-opinion-fb-deepseek.md",
        }
        self.assertTrue(expected_fallbacks.issubset(got))
        for f in expected_fallbacks:
            self.assertIn("hidden: true", (ROOT / ".kilo" / "agents" / f).read_text(encoding="utf-8"))

    def test_primary_pins(self):
        expected = {
            "roteirista-harness-v77.md": "qwen/qwen3.7-max-2026-06-08",
            "rh77-dna.md": "qwen/qwen3.7-max-2026-05-20",
            "rh77-b-decompiler.md": "qwen/qwen3.7-max-2026-05-17",
            "rh77-rewriter.md": "qwen/qwen3.8-max",
            "rh77-critic.md": "qwen/deepseek-v4-pro",
            "rh77-second-opinion.md": "qwen/glm-5.2",
        }
        for f, model in expected.items():
            text = (ROOT / ".kilo" / "agents" / f).read_text(encoding="utf-8")
            self.assertIn(f"model: {model}", text)

    def test_rewriter_explicitly_forbids_raw_b(self):
        text = (ROOT / ".kilo" / "agents" / "rh77-rewriter.md").read_text(encoding="utf-8")
        self.assertIn("NÃO recebe", text)
        self.assertIn("b_content_ledger_file", text)
        self.assertIn("b_scaffold_signature", text)

    def test_main_has_automatic_failover_protocol(self):
        text = (ROOT / ".kilo" / "agents" / "roteirista-harness-v77.md").read_text(encoding="utf-8")
        self.assertIn("model-failure", text)
        self.assertIn("QUOTA EXHAUSTED", text)
        self.assertIn("MODEL_POOL_EXHAUSTED", text)

    def test_final_folder_at_root(self):
        self.assertTrue((ROOT / "roteiro final").is_dir())

    def test_provider_has_no_secret(self):
        text = (ROOT / "kilo.jsonc").read_text(encoding="utf-8")
        self.assertNotIn("apiKey", text)
        self.assertIn('"qwen"', text)
        for mid in ["qwen3.7-max-2026-05-20", "qwen3.7-max-2026-05-17", "qwen3.7-max-preview", "qwen3.6-max-preview"]:
            self.assertIn(mid, text)

    def test_golden_fixture(self):
        fx = ROOT / "tests" / "fixtures" / "golden_failure_001"
        for f in ["VIDEO A.txt", "VIDEO B.txt", "OLD_BAD_FINAL.md"]:
            self.assertTrue((fx / f).exists())

    def test_rewriter_requires_arquivo_f_style_format(self):
        text = (ROOT / ".kilo" / "agents" / "rh77-rewriter.md").read_text(encoding="utf-8")
        self.assertIn("**GANCHO**", text)
        self.assertIn("**BLOCO 1 -", text)
        self.assertIn("**FECHAMENTO**", text)
        self.assertIn("format_contract_file", text)

    def test_cli_has_format_file_and_editorial_parser(self):
        text = (ROOT / "rh7_cli.py").read_text(encoding="utf-8")
        self.assertIn("--format-file", text)
        self.assertIn("validate_output_format", text)
        self.assertIn("EDITORIAL_FORMAT_ONLY", text)


if __name__ == "__main__":
    unittest.main()
