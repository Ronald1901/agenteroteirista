import json
import shutil
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import rh7_cli as cli


class CliTests(unittest.TestCase):
    def setUp(self):
        shutil.rmtree(cli.RUNTIME, ignore_errors=True)
        cli.ensure_runtime_dirs()
        self.fx = ROOT / "tests" / "_tmp_inputs"
        self.fx.mkdir(parents=True, exist_ok=True)
        self.a = self.fx / "VIDEO A.txt"
        self.b = self.fx / "VIDEO B.txt"
        self.f = self.fx / "arquivo F.txt"
        self.f.write_text("**GANCHO**\n\nmodelo\n\n**BLOCO 1 - Exemplo**\n\ntexto\n\n**BLOCO 2 - Exemplo**\n\ntexto\n\n**BLOCO 3 - Exemplo**\n\ntexto\n\n**FECHAMENTO**\n\nfim\n", encoding="utf-8")
        self.a.write_text("Gancho analítico. " + "vozA detalhe ritmo evidência " * 80, encoding="utf-8")
        self.b.write_text("conteudoB fato teoria opiniao " * 60, encoding="utf-8")
        self.created = []

    def tearDown(self):
        shutil.rmtree(cli.RUNTIME, ignore_errors=True)
        shutil.rmtree(self.fx, ignore_errors=True)
        for p in cli.FINAL_DIR.glob("roteiro_final_*.txt"):
            p.unlink(missing_ok=True)
        (cli.FINAL_DIR / "ULTIMO_ROTEIRO.txt").unlink(missing_ok=True)
        for p in cli.FINAL_DIR.glob("locucao_limpa_*.txt"):
            p.unlink(missing_ok=True)
        (cli.FINAL_DIR / "ULTIMA_LOCUCAO_LIMPA.txt").unlink(missing_ok=True)

    def new_run(self):
        obj = cli.create_run(str(self.a), str(self.b), format_file=str(self.f))
        self.created.append(obj["run_id"])
        return cli.RUNS / obj["run_id"], obj

    def dna_obj(self, binding):
        return {
            "schema_version": "7.7",
            "source_role": "FORM_VOICE_DNA_ONLY",
            "source_sha256": binding["A"]["sha256"],
            "north_star": "x",
            "formula_summary": "x",
            "signature_traits": [{"priority": i, "trait": f"t{i}"} for i in range(1, 6)],
            "hook_engine": {}, "narrative_engine": {}, "retention_engine": {}, "evidence_engine": {},
            "pacing_engine": {}, "voice_fingerprint": {}, "syntax_fingerprint": {}, "paragraph_engine": {},
            "transition_engine": {}, "emotional_engine": {}, "cta_engine": {}, "ending_engine": {},
            "abstract_pattern_templates": [], "transfer_rules": [], "surface_markers_to_avoid_copying": [],
            "anti_generic_checks": [], "confidence": {"level": "HIGH", "limits": []},
            "contains_source_prose": False,
        }

    def put_dna(self, d, binding):
        cli.jdump(d / "artifacts" / "a_dna_candidate.json", self.dna_obj(binding))
        cli.next_action(d)

    def put_b_decompiler(self, d, binding):
        cli.jdump(d / "artifacts" / "b_content_ledger_candidate.json", {
            "schema_version": "7.7",
            "source_role": "CONTENT_TOPIC_ORDER_LENGTH_ONLY",
            "source_sha256": binding["B"]["sha256"],
            "target_words": binding["target_words"],
            "topic_spine": ["T01"],
            "topics": [{
                "topic_id": "T01", "position": 1, "label": "tema", "purpose": "explicar",
                "content_units": [
                    {"id": "T01-C001", "kind": "FACT", "neutral_content": "fato um", "certainty": "FACT", "entities": [], "numbers": [], "dependencies": []},
                    {"id": "T01-C002", "kind": "THEORY", "neutral_content": "teoria dois", "certainty": "SPECULATION", "entities": [], "numbers": [], "dependencies": []},
                    {"id": "T01-C003", "kind": "OPINION", "neutral_content": "opiniao tres", "certainty": "OPINION", "entities": [], "numbers": [], "dependencies": []},
                ],
            }],
            "global_constraints": [], "protected_names_numbers": [], "contains_source_surface_prose": False,
        })
        cli.jdump(d / "artifacts" / "b_scaffold_signature_candidate.json", {
            "schema_version": "7.7", "source_role": "CRITIC_ONLY_B_FORM_SIGNATURE", "source_sha256": binding["B"]["sha256"],
            "opening_mechanism": "linear", "block_progression": "linear", "retention_logic": "baixa",
            "pacing": "constante", "transition_logic": "sequencial", "evidence_rhythm": "enumerativo",
            "syntax_voice": "neutro", "ending_logic": "review", "rhetorical_habits": [], "line_by_line_risk_patterns": [],
        })
        cli.next_action(d)

    def setup_until_writer_task(self, d, binding):
        n = cli.next_action(d); self.assertEqual(n["target"], "rh77-dna")
        self.put_dna(d, binding)
        n = cli.next_action(d); self.assertEqual(n["target"], "rh77-b-decompiler")
        self.put_b_decompiler(d, binding)
        n = cli.next_action(d); self.assertEqual(n["target"], "rh77-rewriter")
        return n

    def put_draft(self, d, binding, iteration, token="resultado"):
        target = binding["target_words"]
        # O alvo conta só a locução, não os rótulos editoriais.
        sizes = [target // 5] * 5
        for i in range(target - sum(sizes)):
            sizes[i] += 1
        sections = [
            ("**GANCHO**", sizes[0]),
            ("**BLOCO 1 - Tema um**", sizes[1]),
            ("**BLOCO 2 - Tema dois**", sizes[2]),
            ("**BLOCO 3 - Tema três**", sizes[3]),
            ("**FECHAMENTO**", sizes[4]),
        ]
        formatted = "\n\n".join(label + "\n\n" + " ".join([token] * n) for label, n in sections)
        (d / "full" / "draft_candidate.txt").write_text(formatted, encoding="utf-8")
        cli.jdump(d / "full" / "rewrite_report_candidate.json", {
            "schema_version": "7.7", "mode": "INITIAL" if iteration == 1 else "REPAIR", "iteration": iteration,
            "b_sha256": binding["B"]["sha256"], "target_words": target, "topic_spine": ["T01"],
            "covered_content_unit_ids": ["T01-C001", "T01-C002", "T01-C003"], "uncovered_content_unit_ids": [],
            "signature_traits_executed": ["t1"], "objective_delta_addressed": [], "preserved_gates": [],
            "raw_b_was_read": False, "transfer_execution": "x",
        })

    def form_matrix(self, closer="A"):
        return {"dimensions": {d: {"closer_to": closer, "reason": "evidencia comparativa"} for d in cli.FORM_DIMENSIONS}}

    def put_critique(self, d, iteration, failed=None, form_closer="A"):
        failed = failed or []
        gates = {}
        for g in cli.GATES:
            obj = {"status": "FAIL" if g in failed else "PASS", "reason": "falha" if g in failed else "ok"}
            if g in cli.CRITICAL_EVIDENCE_GATES and g not in failed:
                obj["evidence"] = [
                    {"location": "opening", "detail": "x"}, {"location": "middle", "detail": "y"}, {"location": "ending", "detail": "z"}
                ]
            gates[g] = obj
        cli.jdump(d / "full" / "critique_candidate.json", {
            "schema_version": "7.7", "draft_sha256": cli.sha256_file(d / "full" / "draft.txt"), "iteration": iteration,
            "status": "OBJECTIVE_NOT_MET" if failed else "OBJECTIVE_MET", "gates": gates,
            "form_comparison": self.form_matrix(form_closer),
            "objective_delta": [{"location": "middle", "failed_gate": g, "problem": "x", "required_change": "corrigir", "preserve": "demais"} for g in failed],
            "release_reason": "ok" if not failed else "",
        })

    def put_release_challenge(self, d, iteration, verdict="CONFIRM_RELEASE"):
        critical_names = ["a_macro_dna", "a_micro_voice", "b_rhetorical_scaffolding_removed", "form_closer_to_a_than_b", "transformation_depth", "anti_a_copy", "voice_caricature"]
        critical = {g: {"status": "PASS", "reason": "ok"} for g in critical_names}
        if verdict == "VETO_RELEASE":
            critical["form_closer_to_a_than_b"] = {"status": "FAIL", "reason": "ainda perto de B"}
        cli.jdump(d / "full" / "second_opinion_candidate.json", {
            "schema_version": "7.7", "mode": "RELEASE_CHALLENGE", "draft_sha256": cli.sha256_file(d / "full" / "draft.txt"),
            "iteration": iteration, "verdict": verdict, "critical_gates": critical,
            "form_comparison": self.form_matrix("A" if verdict == "CONFIRM_RELEASE" else "B"),
            "advice": [] if verdict == "CONFIRM_RELEASE" else [{"location": "global", "failed_gate": "form_closer_to_a_than_b", "problem": "perto de B", "required_change": "reconstruir", "preserve": "conteudo"}],
        })

    def test_models_and_new_decompiler(self):
        self.assertEqual(cli.MODEL_MAIN, "qwen/qwen3.7-max-2026-06-08")
        self.assertEqual(cli.MODEL_DNA, "qwen/qwen3.7-max-2026-05-20")
        self.assertEqual(cli.MODEL_B_DECOMPILER, "qwen/qwen3.7-max-2026-05-17")
        self.assertEqual(cli.MODEL_REWRITER, "qwen/qwen3.8-max")
        self.assertEqual(cli.MODEL_CRITIC, "qwen/deepseek-v4-pro")
        self.assertEqual(cli.MODEL_SECOND_OPINION, "qwen/glm-5.2")

    def test_writer_task_never_contains_raw_b(self):
        d, obj = self.new_run(); binding = cli.jload(d / "binding.json")
        n = self.setup_until_writer_task(d, binding)
        task = cli.jload(ROOT / n["task_file"])
        self.assertNotIn("b_file", task)
        self.assertNotIn("b_scaffold_signature_file", task)
        self.assertIn("b_content_ledger_file", task)
        self.assertIn("a_file", task)

    def test_release_requires_glm_challenge_and_writes_root_final_folder(self):
        d, obj = self.new_run(); binding = cli.jload(d / "binding.json")
        self.setup_until_writer_task(d, binding)
        self.put_draft(d, binding, 1)
        n = cli.next_action(d); self.assertEqual(n["target"], "rh77-critic")
        self.put_critique(d, 1, [])
        n = cli.next_action(d)
        self.assertEqual(n["target"], "rh77-second-opinion")
        self.assertEqual(n["stage"], "RELEASE_CHALLENGE")
        self.put_release_challenge(d, 1, "CONFIRM_RELEASE")
        n = cli.next_action(d)
        self.assertTrue(n["done"]); self.assertEqual(n["status"], "RELEASED")
        final = ROOT / n["final_path"]
        self.assertEqual(final.parent.name, "roteiro final")
        self.assertTrue(final.exists())
        self.assertTrue((cli.FINAL_DIR / "ULTIMO_ROTEIRO.txt").exists())
        self.assertTrue((cli.FINAL_DIR / "ULTIMA_LOCUCAO_LIMPA.txt").exists())
        final_text = final.read_text(encoding="utf-8")
        self.assertIn("**GANCHO**", final_text)
        self.assertIn("**BLOCO 1 -", final_text)
        self.assertIn("**FECHAMENTO**", final_text)
        clean_text = (cli.FINAL_DIR / "ULTIMA_LOCUCAO_LIMPA.txt").read_text(encoding="utf-8")
        self.assertNotIn("**GANCHO**", clean_text)

    def test_glm_can_veto_false_positive_and_force_repair(self):
        d, obj = self.new_run(); binding = cli.jload(d / "binding.json")
        self.setup_until_writer_task(d, binding)
        self.put_draft(d, binding, 1)
        cli.next_action(d); self.put_critique(d, 1, [])
        n = cli.next_action(d); self.assertEqual(n["stage"], "RELEASE_CHALLENGE")
        self.put_release_challenge(d, 1, "VETO_RELEASE")
        n = cli.next_action(d)
        self.assertEqual(n["target"], "rh77-rewriter")
        delta = cli.jload(d / "full" / "objective_delta.json")
        self.assertEqual(delta["source"], "GLM_RELEASE_VETO")

    def test_critic_pass_with_b_like_form_matrix_is_rejected(self):
        d, obj = self.new_run(); binding = cli.jload(d / "binding.json")
        self.setup_until_writer_task(d, binding); self.put_draft(d, binding, 1)
        cli.next_action(d)
        self.put_critique(d, 1, [], form_closer="B")
        ok, errors = cli.accept_critique_candidate(d, cli.deterministic_audit(d, binding))
        self.assertFalse(ok)
        self.assertTrue(any("form_matrix" in e for e in errors))

    def test_golden_failure_is_rejected(self):
        out = cli.golden_failure_check()
        self.assertTrue(out["ok"])
        codes = [x["code"] for x in out["audit"]["hard_failures"]]
        self.assertTrue("A_LITERAL_8GRAM" in codes or "MARKDOWN_HEADING_IN_LOCUTION" in codes)

    def test_objective_contains_new_transfer_gates(self):
        d, obj = self.new_run()
        objective = cli.jload(d / "objective.json")
        self.assertIn("form_matrix_rule", objective["release_rule"])
        self.assertIn("b_rhetorical_scaffolding_removed", cli.GATES)
        self.assertIn("voice_caricature", cli.GATES)

    def test_resume_latest(self):
        d, obj = self.new_run()
        self.assertEqual(cli.latest_incomplete_run().resolve(), d.resolve())

    def test_dna_quota_failover_selects_next_snapshot_without_quality_penalty(self):
        d, obj = self.new_run()
        n1 = cli.next_action(d)
        self.assertEqual(n1["model"], "qwen/qwen3.7-max-2026-05-20")
        self.assertEqual(n1["target"], "rh77-dna")
        before = dict(cli._state(d).get("invalid_outputs") or {})
        rec = cli.record_model_failure(d, "DNA", n1["model"], "quota_exhausted")
        n2 = cli.next_action(d)
        self.assertEqual(n2["model"], "qwen/qwen3.7-max-2026-05-17")
        self.assertEqual(n2["target"], "rh77-dna-fb-0517")
        self.assertTrue(n2["failover_active"])
        self.assertEqual(before, dict(cli._state(d).get("invalid_outputs") or {}))
        self.assertEqual(cli._state(d)["model_failover_count"], 1)

    def test_writer_quota_failure_does_not_increment_draft(self):
        d, obj = self.new_run(); binding = cli.jload(d / "binding.json")
        n = self.setup_until_writer_task(d, binding)
        self.assertEqual(n["model"], "qwen/qwen3.8-max")
        cli.record_model_failure(d, "REWRITER", n["model"], "quota_exhausted")
        n2 = cli.next_action(d)
        self.assertEqual(n2["model"], "qwen/qwen3.7-max-preview")
        self.assertEqual(n2["target"], "rh77-rewriter-fb-preview")
        self.assertEqual(cli._state(d)["draft_count"], 0)

    def test_critic_fallback_keeps_second_opinion_model_independent(self):
        d, obj = self.new_run(); binding = cli.jload(d / "binding.json")
        self.setup_until_writer_task(d, binding); self.put_draft(d, binding, 1)
        n = cli.next_action(d)
        self.assertEqual(n["model"], "qwen/deepseek-v4-pro")
        cli.record_model_failure(d, "CRITIC", n["model"], "quota_exhausted")
        n = cli.next_action(d)
        self.assertEqual(n["model"], "qwen/glm-5.2")
        self.assertEqual(n["target"], "rh77-critic-fb-glm52")
        self.put_critique(d, 1, [])
        n = cli.next_action(d)
        self.assertEqual(n["stage"], "RELEASE_CHALLENGE")
        self.assertNotEqual(n["model"], "qwen/glm-5.2")
        self.assertEqual(n["model"], "qwen/qwen3.7-max-preview")

    def test_model_pool_exhausted_is_recoverable_not_quality_blocked(self):
        d, obj = self.new_run()
        for model, _ in cli.MODEL_POOLS["DNA"]:
            cli.record_model_failure(d, "DNA", model, "quota_exhausted")
        n = cli.next_action(d)
        self.assertEqual(n["status"], "MODEL_POOL_EXHAUSTED")
        self.assertTrue(n["recoverable"])
        self.assertNotEqual(cli._state(d)["status"], "QUALITY_BLOCKED")

    def test_rejected_dna_is_archived_not_deleted_without_trace(self):
        d, obj = self.new_run(); binding = cli.jload(d / "binding.json")
        cli.next_action(d)
        bad = self.dna_obj(binding)
        bad["formula_summary"] = " ".join(self.a.read_text(encoding="utf-8").split()[:12])
        cli.jdump(d / "artifacts" / "a_dna_candidate.json", bad)
        ok, errors = cli.accept_dna_candidate(d, binding)
        self.assertFalse(ok)
        self.assertTrue(errors)
        rejected = list((d / "rejected" / "dna").rglob("a_dna_candidate.json"))
        self.assertTrue(rejected)

    def test_format_reference_is_bound_as_editorial_only(self):
        d, obj = self.new_run()
        binding = cli.jload(d / "binding.json")
        contract = cli.jload(d / "format_contract.json")
        self.assertEqual(binding["F"]["role"], "EDITORIAL_FORMAT_ONLY")
        self.assertEqual(contract["source"], "FORMAT_REFERENCE_F")
        self.assertGreaterEqual(contract["reference_block_count"], 3)

    def test_plain_unformatted_draft_is_rejected(self):
        text = "palavra " * 200
        fmt = cli.validate_output_format(text, cli._default_format_contract())
        self.assertEqual(fmt["status"], "FAIL")
        self.assertIn("missing_editorial_labels", fmt["errors"])

    def test_arquivo_f_style_is_accepted_and_labels_do_not_count_as_words(self):
        narration = ["voz"] * 100
        parts = [
            "**GANCHO**\n\n" + " ".join(narration[:20]),
            "**BLOCO 1 - Primeiro tema**\n\n" + " ".join(narration[20:45]),
            "**BLOCO 2 - Segundo tema**\n\n" + " ".join(narration[45:70]),
            "**BLOCO 3 - Terceiro tema**\n\n" + " ".join(narration[70:90]),
            "**FECHAMENTO**\n\n" + " ".join(narration[90:]),
        ]
        text = "\n\n".join(parts)
        fmt = cli.validate_output_format(text, cli._default_format_contract())
        self.assertEqual(fmt["status"], "PASS", fmt)
        self.assertEqual(fmt["narration_words"], 100)

    def test_current_v771_unformatted_result_would_fail_format_contract(self):
        sample = "E se a decisão mais perigosa fosse outra?\n\nTexto sem rótulos editoriais."
        audit = cli.audit_texts("a fonte", "b fonte", sample, {"min": 1, "max": 1000, "target": 10, "margin_pct": .05}, cli._default_format_contract())
        codes = [x["code"] for x in audit["hard_failures"]]
        self.assertIn("OUTPUT_FORMAT_CONTRACT", codes)


if __name__ == "__main__":
    unittest.main()
